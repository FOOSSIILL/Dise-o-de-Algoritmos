



  function Named(firstName: string, lastName: string) {
    return firstName + '' + lastName;
  }
  




myObject.x.y.z;

