const dato = 7;

function factorial(x: number) {
    let r = 1;
   for(let i = x; i>0; i--){
    r *= i;
}

console.log(r);


  }

factorial (dato);
