import './components/index.js';

declare class Appcontainer extends HTMLElement {
    constructor();
    connectedCallback(): void;
    render(): void;
}
declare class head extends HTMLElement {
    constructor();
    connectedCallback(): void;
    render(): void;
}
declare class Barra extends HTMLElement {
    constructor();
    connectedCallback(): void;
    render(): void;
}
